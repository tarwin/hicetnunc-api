const lib = require('./index')

lib.app.listen(3001)
console.log('SERVER RUNNING ON localhost:3001')